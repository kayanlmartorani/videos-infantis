import { useState } from 'react';
import VideoGenerator from './components/VideoGenerator';
import ContentCalendar from './components/ContentCalendar';
import ScriptTemplates from './components/ScriptTemplates';
import QuickIdeas from './components/QuickIdeas';

export default function App() {
  const [activeTab, setActiveTab] = useState('gerador');

  const tabs = [
    { id: 'gerador', label: 'Gerador de Vídeos', icon: '🎬', desc: 'Roteiros completos prontos' },
    { id: 'calendario', label: 'Calendário Editorial', icon: '📅', desc: '30 dias planejados' },
    { id: 'templates', label: 'Templates Prontos', icon: '📋', desc: 'Modelos reutilizáveis' },
    { id: 'rapidas', label: 'Ideias Rápidas', icon: '⚡', desc: 'Shorts e vídeos curtos' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-pink-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-lg border-b border-purple-100 shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent flex items-center gap-2">
                <span>🎬</span> Fábrica de Vídeos Kids
              </h1>
              <p className="text-sm text-gray-500 mt-1">
                Roteiros completos prontos para gravar e publicar no YouTube
              </p>
            </div>
            <div className="hidden md:flex items-center gap-2 bg-purple-50 px-4 py-2 rounded-full">
              <span className="text-sm font-medium text-purple-700">🎯 Canal: Benjamin & Pai</span>
            </div>
          </div>

          {/* Tabs */}
          <div className="flex gap-2 overflow-x-auto pb-1">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all ${
                  activeTab === tab.id
                    ? 'bg-purple-600 text-white shadow-md'
                    : 'bg-white text-gray-600 hover:bg-purple-50 border border-gray-200'
                }`}
              >
                <span>{tab.icon}</span>
                <span>{tab.label}</span>
              </button>
            ))}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        {activeTab === 'gerador' && <VideoGenerator />}
        {activeTab === 'calendario' && <ContentCalendar />}
        {activeTab === 'templates' && <ScriptTemplates />}
        {activeTab === 'rapidas' && <QuickIdeas />}
      </main>

      {/* Footer */}
      <footer className="bg-white/60 backdrop-blur border-t border-purple-100 py-6 mt-12">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p className="text-gray-500 text-sm">
            📋 Todos os roteiros são prontos para gravação — basta seguir as indicações de cena e fala
          </p>
          <p className="text-gray-400 text-xs mt-2">
            Canal: Benjamin & Pai • Nicho: Histórias Infantis • Foco: Aprendizado + Moral + Diversão
          </p>
        </div>
      </footer>
    </div>
  );
}
