import { useState } from 'react';

interface Template {
  id: number;
  name: string;
  description: string;
  icon: string;
  structure: string[];
  example: string;
  useCases: string[];
  tips: string[];
}

const templates: Template[] = [
  {
    id: 1,
    name: "Aventura de Imaginação",
    description: "Benjamin e o pai entram num mundo imaginário. Perfeito para ensinar valores através de brincadeira.",
    icon: "🗺️",
    structure: [
      "1. GANCHO (0-20s): Benjamin encontra algo que desperta imaginação (caixa, mapa, objeto mágico)",
      "2. CENA 1 (20s-1:30): Pai entra na brincadeira, estabelece o mundo imaginário",
      "3. CENA 2 (1:30-3:00): Aventura começa, primeiro desafio aparece",
      "4. CENA 3 (3:00-4:30): Conflito/problema que precisa resolver",
      "5. CENA 4 (4:30-5:30): Solução criativa com aprendizado embutido",
      "6. FECHAMENTO (5:30-6:00): Volta ao real, Benjamin aplica o aprendizado",
      "7. CTA (6:00-6:30): Pergunta para a criança + inscrição"
    ],
    example: "Benjamin acha mapa → viram piratas → tesouro que precisa dividir → aprende a compartilhar",
    useCases: ["Piratas", "Espaço", "Floresta Encantada", "Fundo do Mar", "Castelo Medieval"],
    tips: [
      "Objeto real que inicia a imaginação prende mais atenção",
      "Pai sempre entra como personagem, nunca como narrador externo",
      "Cada desafio tem uma resposta que a criança pode adivinhar"
    ]
  },
  {
    id: 2,
    name: "Rotina Transformada",
    description: "Uma rotina chata (banho, dormir, comer) vira aventura. Os pais AMAM esse formato porque ajuda em casa.",
    icon: "🌙",
    structure: [
      "1. GANCHO (0-15s): Benjamin resiste à rotina ('Não quero!')",
      "2. TRANSFORMAÇÃO (15s-1:00): Pai transforma a rotina em jogo/aventura",
      "3. ETAPA 1 (1:00-2:00): Primeira parte da rotina como desafio divertido",
      "4. ETAPA 2 (2:00-3:00): Segunda parte, mais elaborada",
      "5. ETAPA 3 (3:00-4:00): Terceira parte, criança já está engajada",
      "6. CONQUISTA (4:00-5:00): Rotina completa, Benjamin se sente vencedor",
      "7. CTA (5:00-5:30): 'E você? Faz igual?'"
    ],
    example: "Não quer dormir → cada bicho tem rotina → imita os bichos → dorme tranquilo",
    useCases: ["Dormir", "Tomar Banho", "Escovar Dentes", "Arrumar Quarto", "Comer Legumes"],
    tips: [
      "Mostrar animais/personagens fazendo a mesma rotina gera identificação",
      "Cada etapa tem um som/efeito diferente para manter atenção",
      "Final calmo para vídeos de dormir, agitado para vídeos de manhã"
    ]
  },
  {
    id: 3,
    name: "Erro e Aprendizado",
    description: "Benjamin comete um erro (mentira, não dividir, birrar), enfrenta consequências e aprende. Pais compartilham muito.",
    icon: "😱",
    structure: [
      "1. GANCHO (0-15s): O ERRO acontece. Impacto imediato.",
      "2. REAÇÃO (15s-1:00): Benjamin tenta esconder/culpar outro",
      "3. MENTIRA CRESCE (1:00-2:00): Cada desculpa piora a situação",
      "4. PERGUNTA À TELA (2:00-2:30): 'O que ele deveria fazer?'",
      "5. PESO (2:30-3:30): Benjamin sente o peso do erro",
      "6. PAI GUIA (3:30-4:30): Pai pergunta, não dá bronca. Guia com amor.",
      "7. CONFISSÃO (4:30-5:00): Benjamin conta a verdade. ALÍVIO.",
      "8. LIÇÃO (5:00-6:00): Pai explica sem sermão. Solução juntos.",
      "9. CTA (6:00-6:30): 'Você já passou por isso?'"
    ],
    example: "Quebra vaso → culpa gato → mentira cresce → pai pergunta → confessa → alívio",
    useCases: ["Mentir", "Não dividir", "Bater em amigo", "Não obedecer", "Ter ciúmes"],
    tips: [
      "NUNCA dar bronca no vídeo. Pai sempre guia com perguntas.",
      "Mostrar o ALÍVIO de contar a verdade é mais importante que o erro",
      "A criança precisa sentir que errar é ok, esconder não é"
    ]
  },
  {
    id: 4,
    name: "Conto Clássico com Twist",
    description: "Recontar um conto conhecido com uma virada moderna. SEO forte + aprendizado novo. Busca alta.",
    icon: "📖",
    structure: [
      "1. GANCHO (0-20s): Benjamin pede para ouvir a história",
      "2. APRESENTAÇÃO (20s-1:00): Pai começa o conto clássico normalmente",
      "3. DESENVOLVIMENTO CLÁSSICO (1:00-3:00): Parte conhecida da história",
      "4. O MOMENTO DIFERENTE (3:00-4:00): Aqui entra a twist! Algo muda.",
      "5. RESOLUÇÃO NOVA (4:00-5:30): Final diferente, com lição moderna",
      "6. BENJAMIM REFLETE (5:30-6:00): 'Então na verdade...'",
      "7. CTA (6:00-6:30): 'Qual conto vocês querem na próxima?'"
    ],
    example: "Três Porquinhos → lobo não é mau, está com fome → porquinhos dividem comida → viram amigos",
    useCases: ["Chapeuzinho Vermelho", "Cinderela", "João e Maria", "Rapunzel", "Pedro e o Lobo"],
    tips: [
      "Título SEMPRE com nome do conto (SEO). Ex: 'Benjamin e Os Três Porquinhos'",
      "Twist deve ensinar empatia, perdão ou pensamento crítico",
      "Manter 70% clássico + 30% diferente. Criança gosta do conhecido."
    ]
  },
  {
    id: 5,
    name: "Desafio/Aprendizado Direto",
    description: "Benjamin aprende algo concreto (números, cores, letras) através de um desafio divertido com o pai.",
    icon: "🔢",
    structure: [
      "1. GANCHO (0-15s): Benjamin não sabe algo e fica frustrado",
      "2. PAI PROPÕE (15s-1:00): 'Vamos aprender juntos? Tenho um truque!'",
      "3. NÍVEL 1 (1:00-2:00): Aprendizado básico, fácil, com vitória",
      "4. NÍVEL 2 (2:00-3:30): Fica mais difícil, Benjamin quase desiste",
      "5. NÍVEL 3 (3:30-4:30): Desafio máximo, criança ajuda a resolver",
      "6. CONQUISTA (4:30-5:00): Benjamin consegue! Celebração!",
      "7. APLICAÇÃO (5:00-5:30): Usa o aprendizado em situação real",
      "8. CTA (5:30-6:00): 'Você consegue? Tenta em casa!'"
    ],
    example: "Não sabe contar até 100 → pai ensina grupos de 10 → cada grupo é uma aventura → consegue!",
    useCases: ["Contar até 100", "Cores do arco-íris", "Letras do alfabeto", "Formas geométricas", "Dias da semana"],
    tips: [
      "Cada nível tem uma mini-vitória para manter motivação",
      "Números/letras aparecem GRANDES na tela",
      "Criança precisa sentir que PODE aprender junto"
    ]
  },
  {
    id: 6,
    name: "Medo Superado",
    description: "Benjamin enfrenta um medo comum. A solução vem de ressignificar (o monstro é amigo, o escuro é mágico).",
    icon: "👻",
    structure: [
      "1. GANCHO (0-15s): O MEDO aparece. Benjamin se assusta.",
      "2. REAÇÃO (15s-1:00): Benjamin quer fugir/esconder",
      "3. PAI ACOLHE (1:00-2:00): 'Eu também tive medo quando era pequeno'",
      "4. INVESTIGAÇÃO (2:00-3:30): Pai propõe investigar juntos",
      "5. DESCOBERTA (3:30-4:30): O medo era outra coisa! Ressoa.",
      "6. AMIZADE (4:30-5:00): Benjamin faz as pazes com o medo",
      "7. CORAGEM (5:00-5:30): 'Agora eu não tenho mais medo!'",
      "8. CTA (5:30-6:00): 'Qual é o seu medo? Conta pra gente!'"
    ],
    example: "Medo do escuro → investiga → descobre que sombras são amigos → dorme tranquilo",
    useCases: ["Escuro", "Monstro", "Tempestade", "Doutor", "Escola nova"],
    tips: [
      "Nunca dizer 'não tenha medo'. Sempre acolher: 'eu também tive'",
      "A transformação do medo deve ser VISUAL (sombra vira amigo)",
      "Pai nunca ridiculariza o medo da criança"
    ]
  },
];

export default function ScriptTemplates() {
  const [selected, setSelected] = useState<Template | null>(null);

  if (selected) {
    return <TemplateDetail template={selected} onBack={() => setSelected(null)} />;
  }

  return (
    <div>
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-gray-800 mb-2">📋 Templates de Roteiro</h2>
        <p className="text-gray-600">6 estruturas reutilizáveis. Escolha um template e adapte para qualquer tema.</p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {templates.map(template => (
          <div
            key={template.id}
            onClick={() => setSelected(template)}
            className="bg-white rounded-2xl shadow-md border border-gray-100 p-6 hover:shadow-xl transition-all cursor-pointer group"
          >
            <span className="text-4xl mb-3 block">{template.icon}</span>
            <h3 className="text-lg font-bold text-gray-800 mb-2">{template.name}</h3>
            <p className="text-sm text-gray-600 mb-4">{template.description}</p>
            <div className="flex flex-wrap gap-1 mb-4">
              {template.useCases.slice(0, 3).map(uc => (
                <span key={uc} className="text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full">{uc}</span>
              ))}
            </div>
            <span className="text-purple-600 font-medium text-sm group-hover:translate-x-1 transition-transform inline-block">
              Ver estrutura →
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

function TemplateDetail({ template, onBack }: { template: Template; onBack: () => void }) {
  const [copied, setCopied] = useState(false);

  const copyTemplate = () => {
    const text = `
TEMPLATE: ${template.name}
${template.description}

ESTRUTURA:
${template.structure.join('\n')}

EXEMPLO:
${template.example}

TEMAS POSSÍVEIS:
${template.useCases.join(', ')}

DICAS:
${template.tips.map(t => `- ${t}`).join('\n')}
    `.trim();

    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div>
      <button onClick={onBack} className="flex items-center gap-2 text-purple-600 hover:text-purple-800 mb-6 font-medium">
        ← Voltar para templates
      </button>

      <div className="bg-gradient-to-r from-purple-600 to-pink-600 rounded-2xl p-6 md:p-8 text-white mb-6">
        <span className="text-5xl mb-3 block">{template.icon}</span>
        <h2 className="text-2xl md:text-3xl font-bold mb-2">{template.name}</h2>
        <p className="text-white/80">{template.description}</p>
      </div>

      <div className="flex gap-3 mb-6">
        <button
          onClick={copyTemplate}
          className="flex items-center gap-2 bg-purple-600 text-white px-5 py-2.5 rounded-xl font-medium hover:bg-purple-700 transition-colors"
        >
          {copied ? '✅ Copiado!' : '📋 Copiar Template'}
        </button>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Structure */}
        <div className="bg-white rounded-xl shadow-md border border-gray-100 p-6">
          <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
            📐 Estrutura do Roteiro
          </h3>
          <div className="space-y-3">
            {template.structure.map((step, i) => (
              <div key={i} className="flex items-start gap-3 p-3 rounded-lg bg-gray-50">
                <span className="bg-purple-100 text-purple-700 text-xs font-bold w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0">
                  {i + 1}
                </span>
                <p className="text-sm text-gray-700">{step}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Details */}
        <div className="space-y-6">
          {/* Example */}
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-5">
            <h3 className="font-bold text-blue-700 mb-2">💡 Exemplo Prático</h3>
            <p className="text-gray-700 text-sm">{template.example}</p>
          </div>

          {/* Use Cases */}
          <div className="bg-white rounded-xl shadow-md border border-gray-100 p-5">
            <h3 className="font-bold text-gray-800 mb-3">🎯 Temas Possíveis</h3>
            <div className="flex flex-wrap gap-2">
              {template.useCases.map(uc => (
                <span key={uc} className="bg-purple-100 text-purple-700 px-3 py-1.5 rounded-full text-sm font-medium">
                  {uc}
                </span>
              ))}
            </div>
          </div>

          {/* Tips */}
          <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-5">
            <h3 className="font-bold text-yellow-800 mb-3 flex items-center gap-2">
              ⚡ Dicas de Ouro
            </h3>
            <ul className="space-y-2">
              {template.tips.map((tip, i) => (
                <li key={i} className="flex items-start gap-2 text-sm text-yellow-800">
                  <span className="text-yellow-500 font-bold">→</span>
                  {tip}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
