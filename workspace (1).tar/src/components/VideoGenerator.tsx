import { useState } from 'react';

interface Scene {
  time: string;
  title: string;
  speaker: string;
  text: string;
  action?: string;
  note?: string;
}

interface VideoScript {
  id: number;
  title: string;
  theme: string;
  duration: string;
  age: string;
  learning: string;
  moral: string;
  thumbnail: { text: string; concept: string; emotion: string };
  hook: string;
  scenes: Scene[];
  cta: string;
  tags: string[];
  difficulty: 'Fácil' | 'Médio' | 'Avançado';
  materials: string[];
}

const allScripts: VideoScript[] = [
  {
    id: 1,
    title: "O Dia em que o Benjamin Não Quis Dividir 🏴‍☠️",
    theme: "Compartilhar",
    duration: "6-7 min",
    age: "3-6 anos",
    learning: "Contar até 6 e dividir em 3 partes iguais",
    moral: "Compartilhar torna a brincadeira melhor",
    thumbnail: {
      text: "É TUDO MEU!",
      concept: "Benjamin de chapéu de pirata abraçando baú de moedas, rosto bravo",
      emotion: "Curiosidade e humor"
    },
    hook: "Benjamin aparece com chapéu de pirata segurando um baú. 'Este tesouro é SÓ meu! Ninguém pode pegar! Vamos contar juntos? Um… dois… três…'",
    scenes: [
      { time: "0:00-0:20", title: "Gancho", speaker: "Benjamin", text: "Este tesouro é SÓ meu! Ninguém pode pegar! Você quer ver o que tem dentro?", action: "Abre o baú mostrando 6 moedas douradas" },
      { time: "0:20-1:00", title: "Contagem", speaker: "Pai", text: "Capitão Benjamin, quantas moedas temos no baú?", action: "Contam juntos: 1, 2, 3, 4, 5, 6. Números aparecem na tela." },
      { time: "1:00-1:30", title: "Pai entra", speaker: "Pai", text: "Ricos mesmo, capitão! Mas um navio precisa de tripulação…", note: "Pai entra como imediato do navio" },
      { time: "1:30-2:00", title: "Chegada do Léo", speaker: "Léo", text: "Benjamin! Vamos brincar de pirata?", action: "Toca campainha. Léo aparece animado." },
      { time: "2:00-2:30", title: "Recusa", speaker: "Benjamin", text: "Não! É MEU! Eu achei primeiro!", action: "Benjamin esconde o baú. Léo fica triste no canto." },
      { time: "2:30-3:00", title: "Brincar sozinho", speaker: "Benjamin", text: "Eu sou o capitão… e… e…", action: "Brincadeira perde a graça. Benjamin olha para Léo triste." },
      { time: "3:00-3:30", title: "Pergunta", speaker: "Narração", text: "Por que ficou chato? Você sabe?", note: "Pausa de 3 segundos para criança responder" },
      { time: "3:30-4:00", title: "Conselho do pai", speaker: "Pai", text: "Capitão, todo navio precisa de tripulação. Um pirata sozinho não tem aventura.", action: "Pai chama Benjamin de lado" },
      { time: "4:00-4:30", title: "Desafio", speaker: "Pai", text: "Vamos fazer um desafio? Dividir as 6 moedas entre 3 piratas!", action: "Moedas se separam em 3 grupos na tela" },
      { time: "4:30-5:00", title: "Divisão", speaker: "Benjamin", text: "Duas para mim, duas para o Léo, duas para você! São… SEIS!", action: "Animação das moedas se dividindo" },
      { time: "5:00-5:30", title: "Brincadeira coletiva", speaker: "Léo", text: "Eu sou o navegador! Olha o mapa!", action: "Os três brincam juntos: mapa, barco de almofadas" },
      { time: "5:30-6:00", title: "Fechamento", speaker: "Benjamin", text: "É muito mais legal com amigos! O tesouro é melhor quando a gente divide!", action: "Os três riem juntos" },
      { time: "6:00-6:30", title: "CTA", speaker: "Benjamin", text: "Você já dividiu um brinquedo com alguém hoje? Se inscreve e clica no sininho!", action: "Acena para a câmera" },
    ],
    cta: "Pais: digam nos comentários qual valor querem ver nas próximas histórias",
    tags: ["compartilhar", "números", "pirata", "amizade"],
    difficulty: "Fácil",
    materials: ["Chapéu de pirata (papel)", "Baú (caixa de sapato decorada)", "6 moedas douradas (papelão ou chocolate)", "Mapa do tesouro (papel)"]
  },
  {
    id: 2,
    title: "Benjamin e a Rotina de Dormir dos Bichos 🌙",
    theme: "Rotina",
    duration: "5-6 min",
    age: "2-5 anos",
    learning: "Sequência de rotina noturna (banho, pijama, escovar, história)",
    moral: "Dormir bem é importante para crescer forte",
    thumbnail: {
      text: "BOA NOITE!",
      concept: "Benjamin de pijama com bichos de pelúcia ao redor, fundo escuro com estrelas",
      emotion: "Aconchego e calma"
    },
    hook: "Benjamin está na cama, não quer dormir. 'Eu não tenho sono!' O pai diz: 'Vamos ver como os bichos se preparam para dormir?'",
    scenes: [
      { time: "0:00-0:20", title: "Gancho", speaker: "Benjamin", text: "Eu não tenho sono! Quero brincar mais!", action: "Benjamin pula na cama" },
      { time: "0:20-0:40", title: "Pai propõe", speaker: "Pai", text: "Vamos ver como os bichos se preparam para dormir? Cada um tem um segredo!", note: "Tom calmo, voz baixa" },
      { time: "0:40-1:30", title: "Urso", speaker: "Pai", text: "O urso primeiro toma um banho quentinho com espuma. Faz assim: shhh shhh", action: "Benjamin imita tomando banho" },
      { time: "1:30-2:20", title: "Coruja", speaker: "Benjamin", text: "E depois? E depois?", action: "Ansioso" },
      { time: "2:20-3:00", title: "Coruja lê", speaker: "Pai", text: "A coruja lê uma história antes de dormir. Uhu uhu! Quer ouvir uma?", action: "Pai pega livro" },
      { time: "3:00-3:40", title: "Peixe", speaker: "Pai", text: "O peixinho se despede de todos os amigos do aquário. Tchau, tchau!", action: "Benjamin acena" },
      { time: "3:40-4:20", title: "Gato", speaker: "Pai", text: "O gato boceja bem grande e se enrosca num lugar quentinho. Miaau…", action: "Benjamin boceja" },
      { time: "4:20-5:00", title: "Benjamin segue", speaker: "Benjamin", text: "Eu quero fazer igual! Banho… história… tchau… bocejo…", action: "Benjamin segue a rotina" },
      { time: "5:00-5:30", title: "Hora de dormir", speaker: "Pai", text: "Agora você está pronto, como os bichos. Boa noite, meu pequeno.", action: "Benjamin deita, fecha os olhos" },
      { time: "5:30-6:00", title: "CTA suave", speaker: "Narração", text: "E você? Qual bicho você é na hora de dormir? Até o próximo vídeo, no seu soninho…", note: "Música de ninar suave" },
    ],
    cta: "Pais: salvem este vídeo para a hora de dormir!",
    tags: ["rotina", "dormir", "animais", "calma"],
    difficulty: "Fácil",
    materials: ["Pijama", "Bichos de pelúcia", "Livro de história", "Escova de dentes", "Luz baixa/abajur"]
  },
  {
    id: 3,
    title: "O Que Aconteceu Quando o Benjamin Mentiu? 😱",
    theme: "Honestidade",
    duration: "7-8 min",
    age: "4-7 anos",
    learning: "Consequência das ações + diferença entre verdade e mentira",
    moral: "A verdade sempre aparece, e contar a verdade alivia o coração",
    thumbnail: {
      text: "QUEM FOI?!",
      concept: "Vaso quebrado no chão, Benjamin com cara de susto, gato olhando inocente",
      emotion: "Suspense e curiosidade"
    },
    hook: "BARULHO de vidro quebrando. Benjamin olha assustado. 'Foi o gato! Não fui eu!' Mas será que foi mesmo?",
    scenes: [
      { time: "0:00-0:15", title: "Gancho", speaker: "Ação", text: "BARULHO de vaso quebrando", action: "Benjamin entra correndo, vê o vaso no chão" },
      { time: "0:15-0:30", title: "Primeira mentira", speaker: "Benjamin", text: "Foi o gato! Ele pulou e quebrou tudo!", action: "Gato passa olhando inocente" },
      { time: "0:30-1:00", title: "Pai chega", speaker: "Pai", text: "O que aconteceu aqui? Quem quebrou o vaso?", action: "Pai entra na sala" },
      { time: "1:00-1:30", title: "Benjamin insiste", speaker: "Benjamin", text: "Foi o gato, pai! Ele pulou da estante!", note: "Benjamin fica nervoso" },
      { time: "1:30-2:00", title: "Mentira cresce", speaker: "Pai", text: "Mas o gato estava comigo na cozinha o tempo todo…", action: "Benjamin percebe o erro" },
      { time: "2:00-2:30", title: "Nova mentira", speaker: "Benjamin", text: "Ah… então foi o vento! A janela estava aberta!", note: "Cada mentira fica maior" },
      { time: "2:30-3:00", title: "Pergunta à tela", speaker: "Narração", text: "Você acha que foi o vento? O que Benjamin deveria fazer?", note: "Pausa de 3 segundos" },
      { time: "3:00-3:30", title: "Peso da mentira", speaker: "Benjamin", text: "Pai… eu… eu…", action: "Benjamin parece carregando algo pesado" },
      { time: "3:30-4:00", title: "Pai se senta", speaker: "Pai", text: "Benjamin, vem cá. Senta aqui comigo.", action: "Pai se senta no sofá, tom calmo" },
      { time: "4:00-4:30", title: "Confissão", speaker: "Benjamin", text: "Fui eu, pai. Eu estava jogando bola dentro de casa e… quebrei o vaso. Desculpa.", action: "Benjamin chora baixinho" },
      { time: "4:30-5:00", title: "Reação do pai", speaker: "Pai", text: "Obrigado por me contar a verdade. O vaso a gente compra outro. Mas a confiança, quando quebra, é mais difícil consertar.", note: "Sem bronca, com amor" },
      { time: "5:00-5:30", title: "Alívio", speaker: "Benjamin", text: "Nossa, pai… agora meu coração tá leve! Parece que tirou uma pedra de cima!", action: "Benjamin sorri aliviado" },
      { time: "5:30-6:00", title: "Juntos", speaker: "Pai", text: "Vamos limpar juntos? E depois, vamos combinar uma regra: bola só no quintal.", action: "Os dois limpam juntos" },
      { time: "6:00-6:30", title: "Lição", speaker: "Benjamin", text: "Pai, mentir é ruim porque a mentira fica cada vez maior, né?", note: "Parafraseando a lição" },
      { time: "6:30-7:00", title: "CTA", speaker: "Benjamin", text: "Você já contou uma verdade difícil? Se inscreve e até a próxima!", action: "Acena para câmera" },
    ],
    cta: "Pais: contem nos comentários como vocês lidam com mentiras em casa",
    tags: ["honestidade", "consequência", "família", "confiança"],
    difficulty: "Médio",
    materials: ["Vaso (pode ser de plástico para quebrar em cena)", "Bola pequena", "Gato de pelúcia ou real"]
  },
  {
    id: 4,
    title: "Benjamin e os Três Porquinhos | Desenho Animado 🐷",
    theme: "Conto Clássico",
    duration: "8-10 min",
    age: "3-7 anos",
    learning: "Persistência + fazer bem feito vs. fazer rápido",
    moral: "O que é feito com cuidado dura mais. E ajudar os outros é importante.",
    thumbnail: {
      text: "3 PORQUINHOS!",
      concept: "3 casas lado a lado (palha, madeira, tijolo), lobo soprando, Benjamin assistindo",
      emotion: "Aventura e suspense"
    },
    hook: "Benjamin abre um livro. 'Pai, conta a história dos Três Porquinhos!' Mas essa versão é diferente… o lobo não é mau, ele está com FOME!",
    scenes: [
      { time: "0:00-0:20", title: "Gancho", speaker: "Benjamin", text: "Pai, conta a história dos Três Porquinhos!", action: "Benjamin abre livro grande" },
      { time: "0:20-0:40", title: "Pai começa", speaker: "Pai", text: "Era uma vez três porquinhos que saíram de casa para construir sua própria casinha…", note: "Tom de narrador" },
      { time: "0:40-1:30", title: "Porquinho 1", speaker: "Pai", text: "O primeiro porquinho tinha pressa. Construiu uma casa de PALHA. Rapidinho!", action: "Casa de palha aparece" },
      { time: "1:30-2:00", title: "Porquinho 1 brinca", speaker: "Porquinho 1", text: "Pronto! Agora vou brincar o dia todo!", action: "Porquinho dança" },
      { time: "2:00-2:40", title: "Porquinho 2", speaker: "Pai", text: "O segundo porquinho também teve pressa. Fez uma casa de MADEIRA.", action: "Casa de madeira aparece" },
      { time: "2:40-3:20", title: "Porquinho 2 brinca", speaker: "Porquinho 2", text: "Agora eu também vou brincar!", action: "Os dois porquinhos brincam" },
      { time: "3:20-4:00", title: "Porquinho 3", speaker: "Pai", text: "Mas o terceiro porquinho pensou: 'Vou fazer com CALMA, bem feito, de TIJOLO.'", action: "Porquinho 3 trabalha devagar" },
      { time: "4:00-4:30", title: "Benjamin pergunta", speaker: "Benjamin", text: "Pai, por que ele é tão devagar?", note: "Pergunta para criança pensar" },
      { time: "4:30-5:00", title: "Lobo chega", speaker: "Pai", text: "Mas aí chegou o lobo. E ele não era mau… ele estava com MUITA FOME!", action: "Lobo aparece com cara faminta" },
      { time: "5:00-5:30", title: "Casa de palha", speaker: "Lobo", text: "Porquinho, me dá um pedacinho de comida? Sopra: FUUUUU!", action: "Casa de palha voa" },
      { time: "5:30-6:00", title: "Casa de madeira", speaker: "Lobo", text: "Porquinho, só um pedacinho! FUUUUU!", action: "Casa de madeira cai" },
      { time: "6:00-6:30", title: "Casa de tijolo", speaker: "Lobo", text: "FUUUUU! FUUUUU!", action: "Casa de tijolo NÃO cai. Lobo cansa." },
      { time: "6:30-7:00", title: "Twist", speaker: "Benjamin", text: "Pai, e se em vez de soprar, a gente desse comida pro lobo?", note: "Benjamin tem a ideia" },
      { time: "7:00-7:30", title: "Solução", speaker: "Pai", text: "Boa ideia! Os porquinhos fizeram uma sopa e dividiram com o lobo!", action: "Os 4 comem juntos" },
      { time: "7:30-8:00", title: "Amizade", speaker: "Lobo", text: "Obrigado… eu só queria um amigo pra jantar comigo.", action: "Todos riem" },
      { time: "8:00-8:30", title: "Lição", speaker: "Benjamin", text: "Então a casa de tijolo foi a melhor porque foi feita com calma! E o lobo virou amigo!", note: "Parafraseando" },
      { time: "8:30-9:00", title: "CTA", speaker: "Benjamin", text: "Qual conto a gente conta semana que vem? Comenta aí! Se inscreve!", action: "Acena" },
    ],
    cta: "Pais: qual conto clássico querem ver na próxima? Comente!",
    tags: ["conto clássico", "persistência", "empatia", "três porquinhos"],
    difficulty: "Médio",
    materials: ["Livro grande de histórias", "3 casinhas (papelão: palha, madeira, tijolo)", "Fantasia de lobo (orelhas)", "3 porquinhos (pelúcia ou desenho)"]
  },
  {
    id: 5,
    title: "Benjamin Perdeu o Dente! 🦷 E Agora?",
    theme: "Crescimento",
    duration: "5-6 min",
    age: "4-7 anos",
    learning: "Corpo humano (dentes de leite vs. permanentes) + lidar com medo",
    moral: "Mudar faz parte de crescer, e o novo pode ser ainda melhor",
    thumbnail: {
      text: "AI, MEU DENTE!",
      concept: "Benjamin com mão na boca, dente na mão, cara de surpresa. Fada brilhando ao fundo",
      emotion: "Surpresa e magia"
    },
    hook: "Benjamin morde uma maçã e… AI! 'Pai, meu dente caiu! Tô doente?!'",
    scenes: [
      { time: "0:00-0:15", title: "Gancho", speaker: "Benjamin", text: "AI! Pai! Meu dente caiu! Tô doente?!", action: "Benjamin segura a boca assustado" },
      { time: "0:15-0:40", title: "Pai acalma", speaker: "Pai", text: "Calma, filho! Deixa eu ver… Isso é uma coisa BOA! Você está crescendo!", action: "Pai examina, sorri" },
      { time: "0:40-1:10", title: "Explicação", speaker: "Pai", text: "Esse era seu dente de bebê. Agora vai nascer um dente de gente grande!", note: "Usar desenho na tela" },
      { time: "1:10-1:40", title: "Benjamin pergunta", speaker: "Benjamin", text: "Mas e o espaço? Vai ficar feio?!", action: "Benjamin tenta sorrir sem dente" },
      { time: "1:40-2:10", title: "Fada do Dente", speaker: "Pai", text: "Você conhece a Fada do Dente? Ela visita as crianças que perdem o dentinho…", action: "Música mágica" },
      { time: "2:10-2:40", title: "Como funciona", speaker: "Pai", text: "Você coloca o dente embaixo do travesseiro, e durante a noite a fada troca por uma moedinha!", action: "Pai demonstra com travesseiro" },
      { time: "2:40-3:10", title: "Benjamin anima", speaker: "Benjamin", text: "Sério?! Vou colocar agora! Mas… e se a fada não vier?", note: "Medo real da criança" },
      { time: "3:10-3:40", title: "Pai garante", speaker: "Pai", text: "A fada sempre vem. Mas sabe o que é mais legal? Você está ficando grande!", action: "Pai abraça" },
      { time: "3:40-4:10", title: "Pergunta à tela", speaker: "Narração", text: "Você já perdeu um dente? Como se sentiu?", note: "Pausa de 3 segundos" },
      { time: "4:10-4:40", title: "Noite", speaker: "Benjamin", text: "Boa noite, fada! Aqui está meu dente!", action: "Benjamin coloca dente no travesseiro" },
      { time: "4:40-5:00", title: "Manhã", speaker: "Benjamin", text: "PAI! OLHA! A fada veio! Uma moeda!", action: "Benjamin encontra moeda" },
      { time: "5:00-5:30", title: "Lição", speaker: "Benjamin", text: "Pai, crescer é meio estranho, mas tem coisas boas também!", note: "Parafraseando" },
      { time: "5:30-6:00", title: "CTA", speaker: "Benjamin", text: "Você já perdeu um dente? Conta pra gente! Se inscreve!", action: "Mostra sorriso banguela" },
    ],
    cta: "Pais: contem como foi quando seu filho perdeu o primeiro dente!",
    tags: ["crescimento", "medo", "fada do dente", "corpo humano"],
    difficulty: "Fácil",
    materials: ["Maçã", "Dente falso (pode fazer de massa ou algodão)", "Travesseiro", "Moeda dourada"]
  },
];

const themes = ["Todos", "Compartilhar", "Rotina", "Honestidade", "Conto Clássico", "Crescimento"];

export default function VideoGenerator() {
  const [selectedTheme, setSelectedTheme] = useState("Todos");
  const [selectedScript, setSelectedScript] = useState<VideoScript | null>(null);
  const [showFullScript, setShowFullScript] = useState(false);

  const filtered = selectedTheme === "Todos" 
    ? allScripts 
    : allScripts.filter(s => s.theme === selectedTheme);

  if (selectedScript) {
    return (
      <ScriptDetail 
        script={selectedScript} 
        onBack={() => { setSelectedScript(null); setShowFullScript(false); }}
        showFull={showFullScript}
        setShowFull={setShowFullScript}
      />
    );
  }

  return (
    <div>
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-gray-800 mb-2">🎬 Gerador de Vídeos</h2>
        <p className="text-gray-600">Escolha um roteiro completo pronto para gravar. Cada um inclui falas, cenas, materiais e thumbnail.</p>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-2 mb-6">
        {themes.map(theme => (
          <button
            key={theme}
            onClick={() => setSelectedTheme(theme)}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
              selectedTheme === theme
                ? 'bg-purple-600 text-white shadow-md'
                : 'bg-white text-gray-600 hover:bg-purple-50 border border-gray-200'
            }`}
          >
            {theme}
          </button>
        ))}
      </div>

      {/* Script Cards */}
      <div className="grid md:grid-cols-2 gap-6">
        {filtered.map(script => (
          <div
            key={script.id}
            className="bg-white rounded-2xl shadow-md border border-gray-100 overflow-hidden hover:shadow-xl transition-all cursor-pointer group"
            onClick={() => setSelectedScript(script)}
          >
            <div className="bg-gradient-to-r from-purple-500 to-pink-500 p-5 text-white">
              <div className="flex items-start justify-between mb-2">
                <span className="bg-white/20 text-xs px-2 py-1 rounded-full">{script.theme}</span>
                <span className={`text-xs px-2 py-1 rounded-full ${
                  script.difficulty === 'Fácil' ? 'bg-green-400/30' :
                  script.difficulty === 'Médio' ? 'bg-yellow-400/30' : 'bg-red-400/30'
                }`}>{script.difficulty}</span>
              </div>
              <h3 className="text-xl font-bold">{script.title}</h3>
            </div>
            <div className="p-5">
              <div className="grid grid-cols-2 gap-3 mb-4">
                <InfoBadge icon="⏱️" label={script.duration} />
                <InfoBadge icon="👶" label={script.age} />
                <InfoBadge icon="📚" label={script.learning.slice(0, 30) + '...'} />
                <InfoBadge icon="💚" label={script.moral.slice(0, 30) + '...'} />
              </div>
              <div className="bg-purple-50 rounded-lg p-3 mb-4">
                <span className="text-xs font-semibold text-purple-600">🎣 Gancho:</span>
                <p className="text-sm text-gray-700 mt-1 line-clamp-2">{script.hook}</p>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex flex-wrap gap-1">
                  {script.tags.slice(0, 3).map(tag => (
                    <span key={tag} className="text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full">#{tag}</span>
                  ))}
                </div>
                <span className="text-purple-600 font-medium text-sm group-hover:translate-x-1 transition-transform">
                  Ver roteiro →
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function InfoBadge({ icon, label }: { icon: string; label: string }) {
  return (
    <div className="flex items-center gap-1.5 bg-gray-50 rounded-lg px-2.5 py-1.5">
      <span className="text-sm">{icon}</span>
      <span className="text-xs text-gray-700 truncate">{label}</span>
    </div>
  );
}

function ScriptDetail({ script, onBack, showFull, setShowFull }: { 
  script: VideoScript; 
  onBack: () => void;
  showFull: boolean;
  setShowFull: (v: boolean) => void;
}) {
  const [copied, setCopied] = useState(false);

  const copyScript = () => {
    const text = `
TÍTULO: ${script.title}
DURAÇÃO: ${script.duration}
IDADE: ${script.age}
APRENDIZADO: ${script.learning}
MORAL: ${script.moral}

MATERIAIS NECESSÁRIOS:
${script.materials.map(m => `- ${m}`).join('\n')}

GANCHO INICIAL:
${script.hook}

CENAS:
${script.scenes.map(s => `[${s.time}] ${s.title}\n${s.speaker}: "${s.text}"${s.action ? `\n(Ação: ${s.action})` : ''}${s.note ? `\n(Nota: ${s.note})` : ''}`).join('\n\n')}

CALL TO ACTION:
${script.cta}

THUMBNAIL SUGERIDA:
Texto: "${script.thumbnail.text}"
Conceito: ${script.thumbnail.concept}
Emoção: ${script.thumbnail.emotion}
    `.trim();

    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div>
      <button onClick={onBack} className="flex items-center gap-2 text-purple-600 hover:text-purple-800 mb-6 font-medium">
        ← Voltar para lista
      </button>

      {/* Header */}
      <div className="bg-gradient-to-r from-purple-600 to-pink-600 rounded-2xl p-6 md:p-8 text-white mb-6">
        <div className="flex flex-wrap items-center gap-2 mb-3">
          <span className="bg-white/20 text-xs px-3 py-1 rounded-full">{script.theme}</span>
          <span className="bg-white/20 text-xs px-3 py-1 rounded-full">⏱️ {script.duration}</span>
          <span className="bg-white/20 text-xs px-3 py-1 rounded-full">👶 {script.age}</span>
          <span className="bg-white/20 text-xs px-3 py-1 rounded-full">{script.difficulty}</span>
        </div>
        <h2 className="text-2xl md:text-3xl font-bold mb-3">{script.title}</h2>
        <div className="grid md:grid-cols-2 gap-4">
          <div className="bg-white/10 rounded-xl p-3">
            <span className="text-xs opacity-70">📚 Aprendizado</span>
            <p className="text-sm font-medium">{script.learning}</p>
          </div>
          <div className="bg-white/10 rounded-xl p-3">
            <span className="text-xs opacity-70">💚 Moral</span>
            <p className="text-sm font-medium">{script.moral}</p>
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="flex flex-wrap gap-3 mb-6">
        <button
          onClick={copyScript}
          className="flex items-center gap-2 bg-purple-600 text-white px-5 py-2.5 rounded-xl font-medium hover:bg-purple-700 transition-colors"
        >
          {copied ? '✅ Copiado!' : '📋 Copiar Roteiro Completo'}
        </button>
        <button
          onClick={() => setShowFull(!showFull)}
          className="flex items-center gap-2 bg-white text-purple-600 px-5 py-2.5 rounded-xl font-medium border border-purple-200 hover:bg-purple-50 transition-colors"
        >
          {showFull ? '📖 Ver Resumo' : '📖 Ver Roteiro Completo'}
        </button>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="md:col-span-2 space-y-6">
          {/* Hook */}
          <div className="bg-red-50 border border-red-200 rounded-xl p-5">
            <h3 className="font-bold text-red-700 mb-2 flex items-center gap-2">
              🎣 Gancho Inicial (primeiros 20 segundos)
            </h3>
            <p className="text-gray-700 italic">"{script.hook}"</p>
          </div>

          {/* Scenes */}
          <div className="bg-white rounded-xl shadow-md border border-gray-100 overflow-hidden">
            <div className="bg-gray-50 px-5 py-3 border-b border-gray-100">
              <h3 className="font-bold text-gray-800">📋 Roteiro Cena a Cena</h3>
            </div>
            <div className="divide-y divide-gray-100">
              {(showFull ? script.scenes : script.scenes.slice(0, 5)).map((scene, i) => (
                <div key={i} className="p-4 hover:bg-gray-50 transition-colors">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-xs font-mono bg-purple-100 text-purple-700 px-2 py-0.5 rounded">
                      {scene.time}
                    </span>
                    <span className="font-semibold text-gray-800 text-sm">{scene.title}</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                      scene.speaker === 'Benjamin' ? 'bg-blue-100 text-blue-700' :
                      scene.speaker === 'Pai' ? 'bg-green-100 text-green-700' :
                      scene.speaker === 'Léo' ? 'bg-orange-100 text-orange-700' :
                      scene.speaker === 'Ação' ? 'bg-gray-100 text-gray-600' :
                      'bg-purple-100 text-purple-700'
                    }`}>
                      {scene.speaker}
                    </span>
                    <p className="text-sm text-gray-700">"{scene.text}"</p>
                  </div>
                  {scene.action && (
                    <p className="text-xs text-gray-500 mt-1 ml-2">🎬 {scene.action}</p>
                  )}
                  {scene.note && (
                    <p className="text-xs text-yellow-600 mt-1 ml-2">💡 {scene.note}</p>
                  )}
                </div>
              ))}
            </div>
            {!showFull && script.scenes.length > 5 && (
              <div className="p-4 bg-gray-50 text-center">
                <button 
                  onClick={() => setShowFull(true)}
                  className="text-purple-600 font-medium text-sm hover:text-purple-800"
                >
                  Ver todas as {script.scenes.length} cenas →
                </button>
              </div>
            )}
          </div>

          {/* CTA */}
          <div className="bg-orange-50 border border-orange-200 rounded-xl p-5">
            <h3 className="font-bold text-orange-700 mb-2">📢 Call to Action</h3>
            <p className="text-gray-700">{script.cta}</p>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Thumbnail */}
          <div className="bg-white rounded-xl shadow-md border border-gray-100 p-5">
            <h3 className="font-bold text-gray-800 mb-3 flex items-center gap-2">
              🎨 Thumbnail Sugerida
            </h3>
            <div className="bg-gradient-to-br from-purple-400 to-pink-400 rounded-lg p-6 text-center text-white mb-3">
              <p className="text-2xl font-black">"{script.thumbnail.text}"</p>
            </div>
            <div className="space-y-2 text-sm">
              <p><span className="font-semibold">Conceito:</span> {script.thumbnail.concept}</p>
              <p><span className="font-semibold">Emoção:</span> {script.thumbnail.emotion}</p>
            </div>
          </div>

          {/* Materials */}
          <div className="bg-white rounded-xl shadow-md border border-gray-100 p-5">
            <h3 className="font-bold text-gray-800 mb-3 flex items-center gap-2">
              🎒 Materiais Necessários
            </h3>
            <ul className="space-y-2">
              {script.materials.map((mat, i) => (
                <li key={i} className="flex items-start gap-2 text-sm text-gray-700">
                  <span className="text-green-500">✓</span>
                  {mat}
                </li>
              ))}
            </ul>
          </div>

          {/* Tags */}
          <div className="bg-white rounded-xl shadow-md border border-gray-100 p-5">
            <h3 className="font-bold text-gray-800 mb-3">🏷️ Tags para YouTube</h3>
            <div className="flex flex-wrap gap-2">
              {script.tags.map(tag => (
                <span key={tag} className="text-xs bg-purple-100 text-purple-700 px-2 py-1 rounded-full">
                  #{tag}
                </span>
              ))}
              <span className="text-xs bg-purple-100 text-purple-700 px-2 py-1 rounded-full">#históriainfantil</span>
              <span className="text-xs bg-purple-100 text-purple-700 px-2 py-1 rounded-full">#desenhoanimado</span>
              <span className="text-xs bg-purple-100 text-purple-700 px-2 py-1 rounded-full">#educaçãoinfantil</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
