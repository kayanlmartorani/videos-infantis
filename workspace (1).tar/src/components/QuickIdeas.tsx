import { useState } from 'react';

interface QuickIdea {
  id: number;
  title: string;
  type: 'short' | 'mini';
  duration: string;
  hook: string;
  body: string;
  ending: string;
  emotion: string;
  tags: string[];
  viralPotential: '🔥🔥🔥' | '🔥🔥' | '🔥';
}

const quickIdeas: QuickIdea[] = [
  {
    id: 1,
    title: "Benjamin Conta Até 10 com Dedos 🖐️",
    type: "short",
    duration: "30 seg",
    hook: "Quantos dedos eu tenho? Vamos contar juntos!",
    body: "Benjamin mostra as mãos. Conta 1-5 na mão esquerda, 6-10 na direita. Cada número aparece grande na tela.",
    ending: "Conseguiu? Mostra seus dedos pra câmera! Se inscreve!",
    emotion: "Participação e conquista",
    tags: ["números", "dedos", "interativo"],
    viralPotential: "🔥🔥🔥"
  },
  {
    id: 2,
    title: "Qual Cor É Essa? 🎨",
    type: "short",
    duration: "25 seg",
    hook: "Vou mostrar uma cor e você grita o nome! Preparado?",
    body: "Objetos coloridos aparecem um por vez: maçã (vermelho), céu (azul), sol (amarelo), grama (verde). Pausa para criança responder.",
    ending: "Acertou todas? Comenta quantas! Se inscreve!",
    emotion: "Desafio e diversão",
    tags: ["cores", "desafio", "interativo"],
    viralPotential: "🔥🔥🔥"
  },
  {
    id: 3,
    title: "Benjamin Divide o Chocolate 🍫",
    type: "short",
    duration: "30 seg",
    hook: "Tenho 1 chocolate e 3 amigos. Como dividir igual?",
    body: "Benjamin quebra o chocolate em 3 partes. Conta: 1 pedaço pra mim, 1 pro Léo, 1 pro pai. Todos comem felizes.",
    ending: "Você já dividiu algo hoje? Se inscreve!",
    emotion: "Satisfação e generosidade",
    tags: ["compartilhar", "divisão", "chocolate"],
    viralPotential: "🔥🔥🔥"
  },
  {
    id: 4,
    title: "O Bocejo Contagioso 😴",
    type: "short",
    duration: "15 seg",
    hook: "(sem fala) Benjamin boceja bem grande...",
    body: "Benjamin boceja. Pai boceja. Gato boceja. Todos bocejam em sequência. Cada vez mais engraçado.",
    ending: "Você bocejou? 😴 Se inscreve e boa noite!",
    emotion: "Humor e fofura",
    tags: ["bocejo", "engraçado", "fofo"],
    viralPotential: "🔥🔥🔥"
  },
  {
    id: 5,
    title: "Grande vs. Pequeno 🐘🐜",
    type: "short",
    duration: "30 seg",
    hook: "O que é GRANDE? E o que é PEQUENO?",
    body: "Benjamin mostra: elefante (grande), formiga (pequeno). Sol (grande), estrela (pequena). Pai (grande), bebê (pequeno).",
    ending: "Ache mais coisas grandes e pequenas em casa! Se inscreve!",
    emotion: "Curiosidade e aprendizado",
    tags: ["opostos", "tamanhos", "animais"],
    viralPotential: "🔥🔥"
  },
  {
    id: 6,
    title: "Benjamin Escova os Dentes 🪥",
    type: "short",
    duration: "30 seg",
    hook: "Olha meus dentes! Estão limpinhos! Quer aprender?",
    body: "Benjamin escova em círculos. Cima, baixo, frente, trás. Conta 2 minutos com musiquinha. Sorriso brilhante.",
    ending: "Você escovou hoje? Mostra seu sorriso! Se inscreve!",
    emotion: "Conquista e higiene",
    tags: ["rotina", "dentes", "saúde"],
    viralPotential: "🔥🔥"
  },
  {
    id: 7,
    title: "A Caixa Surpresa 📦",
    type: "short",
    duration: "30 seg",
    hook: "O que tem dentro dessa caixa? Vamos descobrir!",
    body: "Benjamin chacoalha a caixa. Barulho. Abre devagar... é um ursinho de pelúcia! Abraça forte. 'É meu amigo!'",
    ending: "O que você acha que era? Comenta! Se inscreve!",
    emotion: "Surpresa e ternura",
    tags: ["surpresa", "caixa", "fofo"],
    viralPotential: "🔥🔥🔥"
  },
  {
    id: 8,
    title: "Benjamin Ajuda a Arrumar 🧹",
    type: "short",
    duration: "25 seg",
    hook: "Quem me ajuda a arrumar? Valendo!",
    body: "Brinquedos no chão. Benjamin guarda um. Pai guarda outro. Juntos, rápido! Tudo limpo em 10 segundos. High five!",
    ending: "Você arrumou seu quarto hoje? Se inscreve!",
    emotion: "Time e conquista",
    tags: ["arrumar", "ajudar", "rotina"],
    viralPotential: "🔥🔥"
  },
  {
    id: 9,
    title: "1, 2, 3... CABRITA! 🐐",
    type: "short",
    duration: "20 seg",
    hook: "Vamos brincar de estátua! 1, 2, 3...",
    body: "Benjamin dança. De repente: 'CABRITA!' Congela. Pai congela. Gato congela. Quem se mexeu? Risadas.",
    ending: "Você conseguiu ficar parado? Tenta com a família! Se inscreve!",
    emotion: "Diversão e movimento",
    tags: ["brincadeira", "estátua", "ativo"],
    viralPotential: "🔥🔥🔥"
  },
  {
    id: 10,
    title: "Benjamin Come Brócolis! 🥦",
    type: "short",
    duration: "25 seg",
    hook: "Isso aqui é uma arvorezinha! Vou comer a floresta!",
    body: "Benjamin finge que o prato é uma floresta. Come os brócolis como se fosse um gigante. 'Nhac nhac nhac! Acabou a floresta!'",
    ending: "Você já comeu sua floresta hoje? Se inscreve!",
    emotion: "Humor e alimentação",
    tags: ["comida", "humor", "legumes"],
    viralPotential: "🔥🔥"
  },
  {
    id: 11,
    title: "Boa Noite, Brinquedos! 🧸",
    type: "short",
    duration: "30 seg",
    hook: "Hora de dormir! Vamos dar boa noite pra todo mundo...",
    body: "Benjamin dá boa noite pra cada brinquedo: 'Boa noite, ursinho. Boa noite, carrinho. Boa noite, dinossauro.' Coloca todos na cama.",
    ending: "Boa noite, amiguinhos! Até amanhã! Se inscreve! 🌙",
    emotion: "Aconchego e rotina",
    tags: ["dormir", "brinquedos", "calma"],
    viralPotential: "🔥🔥🔥"
  },
  {
    id: 12,
    title: "Benjamin Desculpa o Amigo 🤝",
    type: "short",
    duration: "30 seg",
    hook: "O Léo derrubou minha torre! Eu tô bravo!",
    body: "Benjamin bravo. Respira fundo. Léo: 'Desculpa...' Benjamin: 'Tá tudo bem. Vamos construir juntos? Mais alto!' Os dois riem.",
    ending: "Você já pediu desculpa hoje? Se inscreve!",
    emotion: "Perdão e amizade",
    tags: ["perdão", "amizade", "valor"],
    viralPotential: "🔥🔥"
  },
  {
    id: 13,
    title: "Que Som É Esse? 🔊",
    type: "short",
    duration: "30 seg",
    hook: "Vou fazer um som e você adivinha o bicho! Pronto?",
    body: "Som de cachorro (au au!). 'É o cachorro!' Som de gato (miau!). 'É o gato!' Som de vaca (muuu!). 'É a vaca!'",
    ending: "Acertou todos? Qual som você sabe fazer? Se inscreve!",
    emotion: "Desafio e diversão",
    tags: ["sons", "animais", "adivinhação"],
    viralPotential: "🔥🔥🔥"
  },
  {
    id: 14,
    title: "Benjamin Vira Super-Herói 🦸",
    type: "short",
    duration: "25 seg",
    hook: "Quando alguém precisa de ajuda... EU VOU!",
    body: "Benjamin coloca capa. 'Super Benjamin!' Ajuda pai a carregar sacola. Ajuda Léo a alcançar brinquedo. 'Herói de verdade ajuda!'",
    ending: "Quem é seu herói? Se inscreve!",
    emotion: "Poder e bondade",
    tags: ["herói", "ajudar", "imaginação"],
    viralPotential: "🔥🔥"
  },
  {
    id: 15,
    title: "Abraço de Urso 🐻🤗",
    type: "short",
    duration: "15 seg",
    hook: "(sem fala) Benjamin corre e abraça o pai bem forte.",
    body: "Abraço longo. Pai retribui. Benjamin: 'Eu te amo, pai.' Pai: 'Eu te amo mais.' Risadas. Corações na tela.",
    ending: "Dá um abraço em quem você ama! Se inscreve! ❤️",
    emotion: "Amor e ternura",
    tags: ["amor", "pai e filho", "fofo"],
    viralPotential: "🔥🔥🔥"
  },
];

export default function QuickIdeas() {
  const [filter, setFilter] = useState<'all' | 'short'>('all');
  const [expandedId, setExpandedId] = useState<number | null>(null);

  const filtered = filter === 'all' ? quickIdeas : quickIdeas.filter(i => i.type === filter);

  return (
    <div>
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-gray-800 mb-2">⚡ Ideias Rápidas para Shorts</h2>
        <p className="text-gray-600">15 ideias de Shorts prontos para gravar. Cada um com gancho, desenvolvimento e encerramento.</p>
      </div>

      {/* Filter */}
      <div className="flex gap-2 mb-6">
        <button
          onClick={() => setFilter('all')}
          className={`px-4 py-2 rounded-full text-sm font-medium ${filter === 'all' ? 'bg-purple-600 text-white' : 'bg-white text-gray-600 border border-gray-200'}`}
        >
          Todos ({quickIdeas.length})
        </button>
        <button
          onClick={() => setFilter('short')}
          className={`px-4 py-2 rounded-full text-sm font-medium ${filter === 'short' ? 'bg-purple-600 text-white' : 'bg-white text-gray-600 border border-gray-200'}`}
        >
          🔥🔥🔥 Virais ({quickIdeas.filter(i => i.viralPotential === '🔥🔥🔥').length})
        </button>
      </div>

      {/* Ideas Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map(idea => (
          <div
            key={idea.id}
            className={`bg-white rounded-xl shadow-md border border-gray-100 overflow-hidden transition-all cursor-pointer ${
              expandedId === idea.id ? 'ring-2 ring-purple-400' : 'hover:shadow-lg'
            }`}
            onClick={() => setExpandedId(expandedId === idea.id ? null : idea.id)}
          >
            {/* Header */}
            <div className="bg-gradient-to-r from-red-500 to-pink-500 p-4 text-white">
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs bg-white/20 px-2 py-0.5 rounded-full">📱 {idea.duration}</span>
                <span className="text-sm">{idea.viralPotential}</span>
              </div>
              <h3 className="font-bold text-sm">{idea.title}</h3>
            </div>

            {/* Content */}
            <div className="p-4">
              <p className="text-xs text-gray-500 mb-2 font-medium uppercase">Gancho</p>
              <p className="text-sm text-gray-700 italic mb-3">"{idea.hook}"</p>

              {expandedId === idea.id && (
                <>
                  <p className="text-xs text-gray-500 mb-1 font-medium uppercase">Desenvolvimento</p>
                  <p className="text-sm text-gray-700 mb-3">{idea.body}</p>

                  <p className="text-xs text-gray-500 mb-1 font-medium uppercase">Encerramento</p>
                  <p className="text-sm text-gray-700 italic mb-3">"{idea.ending}"</p>

                  <div className="bg-purple-50 rounded-lg p-2 mb-3">
                    <span className="text-xs font-semibold text-purple-600">Emoção: </span>
                    <span className="text-xs text-gray-700">{idea.emotion}</span>
                  </div>
                </>
              )}

              <div className="flex flex-wrap gap-1">
                {idea.tags.map(tag => (
                  <span key={tag} className="text-xs bg-gray-100 text-gray-500 px-1.5 py-0.5 rounded">#{tag}</span>
                ))}
              </div>

              <p className="text-xs text-purple-600 mt-2 font-medium">
                {expandedId === idea.id ? 'Clique para fechar ↑' : 'Clique para ver mais ↓'}
              </p>
            </div>
          </div>
        ))}
      </div>

      {/* Tips */}
      <div className="mt-8 bg-white rounded-2xl shadow-lg border border-gray-100 p-6">
        <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
          <span>📱</span> Regras de Ouro para Shorts Infantis
        </h3>
        <div className="grid md:grid-cols-2 gap-4">
          <TipCard emoji="🎯" title="15-30 segundos" desc="Curto e direto. Sem introdução longa." />
          <TipCard emoji="😂" title="Gag visual" desc="Uma piada ou momento fofo. Não precisa de diálogo." />
          <TipCard emoji="🔊" title="Som claro" desc="Efeitos sonoros ajudam. Música suave de fundo." />
          <TipCard emoji="📝" title="Texto na tela" desc="Palavras-chave aparecem grandes. Ajuda retenção." />
          <TipCard emoji="🔄" title="Loop" desc="Final que conecta com o início. Faz assistir de novo." />
          <TipCard emoji="❤️" title="Emoção forte" desc="Surpresa, humor ou ternura. Sem emoção, sem viral." />
        </div>
      </div>

      {/* Quick Formula */}
      <div className="mt-6 bg-gradient-to-r from-purple-600 to-pink-600 rounded-2xl p-6 text-white">
        <h3 className="font-bold mb-4 flex items-center gap-2">
          <span>🧪</span> Fórmula do Short Viral
        </h3>
        <div className="grid md:grid-cols-4 gap-4">
          <div className="bg-white/10 rounded-xl p-4 text-center">
            <span className="text-2xl">🎣</span>
            <p className="text-xs mt-2 font-medium">GANCHO (3s)</p>
            <p className="text-xs opacity-70">Pergunta ou ação surpreendente</p>
          </div>
          <div className="bg-white/10 rounded-xl p-4 text-center">
            <span className="text-2xl">📈</span>
            <p className="text-xs mt-2 font-medium">DESENVOLVIMENTO (15-20s)</p>
            <p className="text-xs opacity-70">Ação principal com emoção</p>
          </div>
          <div className="bg-white/10 rounded-xl p-4 text-center">
            <span className="text-2xl">😱</span>
            <p className="text-xs mt-2 font-medium">CLÍMAX (3-5s)</p>
            <p className="text-xs opacity-70">Momento de surpresa/risada</p>
          </div>
          <div className="bg-white/10 rounded-xl p-4 text-center">
            <span className="text-2xl">🔁</span>
            <p className="text-xs mt-2 font-medium">LOOP/CTA (2s)</p>
            <p className="text-xs opacity-70">Conecta com início ou pergunta</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function TipCard({ emoji, title, desc }: { emoji: string; title: string; desc: string }) {
  return (
    <div className="flex items-start gap-3 p-3 rounded-lg bg-gray-50">
      <span className="text-xl">{emoji}</span>
      <div>
        <p className="font-semibold text-gray-800 text-sm">{title}</p>
        <p className="text-xs text-gray-600">{desc}</p>
      </div>
    </div>
  );
}
