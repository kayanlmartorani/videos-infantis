import { useState } from 'react';

interface CalendarDay {
  day: number;
  type: 'video' | 'short' | 'compilation' | 'rest';
  title?: string;
  theme?: string;
  time?: string;
  status: 'planned' | 'ready' | 'published';
}

const calendarData: CalendarDay[][] = [
  // Week 1
  [
    { day: 1, type: 'video', title: 'Benjamin Não Quis Dividir 🏴‍☠️', theme: 'Compartilhar', time: '17:00', status: 'planned' },
    { day: 2, type: 'short', title: 'Benjamin conta moedas (corte)', theme: 'Números', time: '12:00', status: 'planned' },
    { day: 3, type: 'rest', status: 'planned' },
    { day: 4, type: 'short', title: 'Léo fica triste (corte emocional)', theme: 'Empatia', time: '12:00', status: 'planned' },
    { day: 5, type: 'short', title: 'Dividindo 6 em 3 (educativo)', theme: 'Matemática', time: '12:00', status: 'planned' },
    { day: 6, type: 'video', title: 'Rotina de Dormir dos Bichos 🌙', theme: 'Rotina', time: '17:00', status: 'planned' },
    { day: 7, type: 'rest', status: 'planned' },
  ],
  // Week 2
  [
    { day: 8, type: 'short', title: 'Urso toma banho (fofo)', theme: 'Rotina', time: '12:00', status: 'planned' },
    { day: 9, type: 'short', title: 'Benjamin boceja (engraçado)', theme: 'Rotina', time: '12:00', status: 'planned' },
    { day: 10, type: 'rest', status: 'planned' },
    { day: 11, type: 'short', title: 'Qual bicho você é? (interativo)', theme: 'Rotina', time: '12:00', status: 'planned' },
    { day: 12, type: 'video', title: 'Quando o Benjamin Mentiu 😱', theme: 'Honestidade', time: '17:00', status: 'planned' },
    { day: 13, type: 'short', title: 'Vaso quebra (suspense)', theme: 'Honestidade', time: '12:00', status: 'planned' },
    { day: 14, type: 'rest', status: 'planned' },
  ],
  // Week 3
  [
    { day: 15, type: 'short', title: 'Benjamin confessa (emocional)', theme: 'Honestidade', time: '12:00', status: 'planned' },
    { day: 16, type: 'short', title: 'Mentira cresce (animação)', theme: 'Honestidade', time: '12:00', status: 'planned' },
    { day: 17, type: 'rest', status: 'planned' },
    { day: 18, type: 'video', title: 'Benjamin e os Três Porquinhos 🐷', theme: 'Conto Clássico', time: '17:00', status: 'planned' },
    { day: 19, type: 'short', title: 'Lobo sopra casas (ação)', theme: 'Conto Clássico', time: '12:00', status: 'planned' },
    { day: 20, type: 'short', title: 'Lobo com fome (fofo)', theme: 'Conto Clássico', time: '12:00', status: 'planned' },
    { day: 21, type: 'rest', status: 'planned' },
  ],
  // Week 4 +
  [
    { day: 22, type: 'short', title: 'Porquinho devagar (lição)', theme: 'Conto Clássico', time: '12:00', status: 'planned' },
    { day: 23, type: 'video', title: 'Benjamin Perdeu o Dente 🦷', theme: 'Crescimento', time: '17:00', status: 'planned' },
    { day: 24, type: 'short', title: 'Dente cai (surpresa)', theme: 'Crescimento', time: '12:00', status: 'planned' },
    { day: 25, type: 'rest', status: 'planned' },
    { day: 26, type: 'short', title: 'Fada do Dente (magia)', theme: 'Crescimento', time: '12:00', status: 'planned' },
    { day: 27, type: 'compilation', title: 'Melhores Aventuras do Benjamin - Ep.1', theme: 'Compilação', time: '17:00', status: 'planned' },
    { day: 28, type: 'rest', status: 'planned' },
  ],
  // Extra
  [
    { day: 29, type: 'short', title: 'Melhores momentos (compilação)', theme: 'Mix', time: '12:00', status: 'planned' },
    { day: 30, type: 'video', title: 'Benjamin Não Quer Tomar Banho 🛁', theme: 'Rotina', time: '17:00', status: 'planned' },
  ],
];

const weekDays = ['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'];

export default function ContentCalendar() {
  const [selectedWeek, setSelectedWeek] = useState(0);
  const [selectedDay, setSelectedDay] = useState<CalendarDay | null>(null);

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'video': return 'bg-purple-100 border-purple-300 text-purple-700';
      case 'short': return 'bg-red-100 border-red-300 text-red-700';
      case 'compilation': return 'bg-blue-100 border-blue-300 text-blue-700';
      default: return 'bg-gray-50 border-gray-200 text-gray-400';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'video': return '🎬';
      case 'short': return '📱';
      case 'compilation': return '📺';
      default: return '😴';
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'video': return 'Vídeo Principal';
      case 'short': return 'Short';
      case 'compilation': return 'Compilação';
      default: return 'Descanso';
    }
  };

  return (
    <div>
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-gray-800 mb-2">📅 Calendário Editorial - 30 Dias</h2>
        <p className="text-gray-600">Planejamento completo de publicação. 2 vídeos/semana + 3-5 Shorts/semana.</p>
      </div>

      {/* Legend */}
      <div className="flex flex-wrap gap-3 mb-6">
        <span className="flex items-center gap-1.5 text-sm"><span className="w-3 h-3 rounded bg-purple-400"></span> Vídeo Principal</span>
        <span className="flex items-center gap-1.5 text-sm"><span className="w-3 h-3 rounded bg-red-400"></span> Short</span>
        <span className="flex items-center gap-1.5 text-sm"><span className="w-3 h-3 rounded bg-blue-400"></span> Compilação</span>
        <span className="flex items-center gap-1.5 text-sm"><span className="w-3 h-3 rounded bg-gray-300"></span> Descanso</span>
      </div>

      {/* Week Selector */}
      <div className="flex gap-2 mb-6 overflow-x-auto">
        {calendarData.map((_, i) => (
          <button
            key={i}
            onClick={() => setSelectedWeek(i)}
            className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all ${
              selectedWeek === i
                ? 'bg-purple-600 text-white'
                : 'bg-white text-gray-600 border border-gray-200 hover:bg-purple-50'
            }`}
          >
            Semana {i + 1}
          </button>
        ))}
      </div>

      {/* Calendar Grid */}
      <div className="bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden mb-8">
        <div className="grid grid-cols-7 border-b border-gray-100">
          {weekDays.map(day => (
            <div key={day} className="p-3 text-center text-sm font-semibold text-gray-500 bg-gray-50">
              {day}
            </div>
          ))}
        </div>
        <div className="grid grid-cols-7">
          {calendarData[selectedWeek].map((day, i) => (
            <div
              key={i}
              onClick={() => day.type !== 'rest' ? setSelectedDay(day) : null}
              className={`p-3 border-r border-b border-gray-100 min-h-[120px] transition-all ${
                day.type !== 'rest' ? 'cursor-pointer hover:bg-purple-50' : ''
              } ${selectedDay?.day === day.day ? 'bg-purple-50 ring-2 ring-purple-400 ring-inset' : ''}`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-bold text-gray-700">{day.day}</span>
                <span className="text-lg">{getTypeIcon(day.type)}</span>
              </div>
              {day.type !== 'rest' && (
                <div className={`text-xs px-2 py-1 rounded border ${getTypeColor(day.type)}`}>
                  <p className="font-semibold truncate">{day.title}</p>
                  <p className="opacity-70 mt-0.5">{day.time}</p>
                </div>
              )}
              {day.type === 'rest' && (
                <p className="text-xs text-gray-400 text-center mt-4">Descanso</p>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Day Detail */}
      {selectedDay && (
        <div className="bg-white rounded-2xl shadow-lg border border-gray-100 p-6 mb-8">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xl font-bold text-gray-800">
              {getTypeIcon(selectedDay.type)} Dia {selectedDay.day} - {getTypeLabel(selectedDay.type)}
            </h3>
            <button onClick={() => setSelectedDay(null)} className="text-gray-400 hover:text-gray-600">✕</button>
          </div>
          <div className="grid md:grid-cols-3 gap-4">
            <div className="bg-purple-50 rounded-xl p-4">
              <span className="text-xs font-semibold text-purple-500">Título</span>
              <p className="font-bold text-gray-800 mt-1">{selectedDay.title}</p>
            </div>
            <div className="bg-blue-50 rounded-xl p-4">
              <span className="text-xs font-semibold text-blue-500">Tema</span>
              <p className="font-bold text-gray-800 mt-1">{selectedDay.theme}</p>
            </div>
            <div className="bg-green-50 rounded-xl p-4">
              <span className="text-xs font-semibold text-green-500">Horário</span>
              <p className="font-bold text-gray-800 mt-1">{selectedDay.time}</p>
            </div>
          </div>
        </div>
      )}

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatBox number="8" label="Vídeos Principais" icon="🎬" color="purple" />
        <StatBox number="15" label="Shorts" icon="📱" color="red" />
        <StatBox number="1" label="Compilação" icon="📺" color="blue" />
        <StatBox number="6" label="Dias de Descanso" icon="😴" color="gray" />
      </div>

      {/* Tips */}
      <div className="mt-8 bg-yellow-50 border border-yellow-200 rounded-2xl p-6">
        <h3 className="font-bold text-yellow-800 mb-3 flex items-center gap-2">
          <span>⚡</span> Regras do Calendário
        </h3>
        <div className="grid md:grid-cols-2 gap-3">
          <Rule text="Vídeos principais: TERÇA e SÁBADO às 17h" />
          <Rule text="Shorts: seg/qua/sex às 12h" />
          <Rule text="Domingo e quarta: descanso" />
          <Rule text="Compilação no dia 27 (sábado)" />
          <Rule text="Shorts são cortes dos vídeos principais" />
          <Rule text="Cada vídeo gera 3-4 Shorts" />
        </div>
      </div>
    </div>
  );
}

function StatBox({ number, label, icon, color }: { number: string; label: string; icon: string; color: string }) {
  const colorMap: Record<string, string> = {
    purple: 'from-purple-400 to-purple-600',
    red: 'from-red-400 to-red-600',
    blue: 'from-blue-400 to-blue-600',
    gray: 'from-gray-400 to-gray-600',
  };
  return (
    <div className="bg-white rounded-xl shadow-md border border-gray-100 p-4 text-center">
      <span className="text-2xl">{icon}</span>
      <p className={`text-3xl font-bold bg-gradient-to-r ${colorMap[color]} bg-clip-text text-transparent mt-1`}>{number}</p>
      <p className="text-xs text-gray-500 mt-1">{label}</p>
    </div>
  );
}

function Rule({ text }: { text: string }) {
  return (
    <div className="flex items-center gap-2 text-sm text-yellow-800">
      <span className="text-yellow-500">✓</span>
      {text}
    </div>
  );
}
